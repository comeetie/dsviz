#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

library(sf)
library(dplyr)
library(leaflet)
library(ggplot2)
library(lubridate)




trees = readRDS("paris_trees.RDS")





# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("Paris tree dashboard"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
          dateRangeInput("period",label = "Période :",start  = "2023-01-01",
                         end    = "2023-12-31",
                         min    = "2021-01-01",
                         max    = "2023-12-31",
                         format = "mm/dd/yy",
                         separator = " / ")
          
        ),

        # Show a plot of the generated distribution
        mainPanel(
          
           h1(textOutput("infos")),leafletOutput("map")
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {

  
  selection = reactive({trees |> filter(
    (dateplantation>=as_datetime(input$period[1]) & dateplantation<=as_datetime(input$period[2]))
    | (datedernierabattage>=as_datetime(input$period[1]) & datedernierabattage<=as_datetime(input$period[2])))
  })
  
  
    output$infos <- renderText({
      
      
      counts =  selection()  |> st_drop_geometry() |> count(status) 
      paste(counts|>filter(status=="cutted")|>pull(n), "arbres coupés, ",counts|>filter(status=="planted")|>pull(n), " plantés")
      
    })
    
    output$map = renderLeaflet({
      leaflet() %>%
         addTiles()  %>%
         addMarkers(data = selection()|>head(1000)) 
    })
    
    
    
}

# Run the application 
shinyApp(ui = ui, server = server)
