library(sf)
library(dplyr)
library(ggplot2)


#planted trees 
planted_tree = st_read("data/les-arbres-plantes.geojson")
str(planted_tree)


# sanity check outliers ?
boxplot(planted_tree$circonferenceencm)
hist(planted_tree$circonferenceencm)
plot(planted_tree$hauteurenm,planted_tree$circonferenceencm)

# missing values ?
apply(planted_tree,2,\(col){sum(is.na(col))})

planted_tree_cleaned  = planted_tree |> 
  mutate(hauteurenm=if_else(hauteurenm>50, NA,hauteurenm)) |>
  select(idbase,domanialite,circonferenceencm,hauteurenm,espece,libellefrancais,dateplantation) |>
  mutate(datedernierabattage=NA,motifabattage=NA)  

# cutted trees  
cutted_tree = st_read("data/arbres-abattus-pour-raison-sanitaires-et-essence-de-remplacement.geojson")
str(cutted_tree)


# missing values ?
apply(cutted_tree,2,\(col){sum(is.na(col))})

cutted_tree_cleaned  = cutted_tree |> 
  select(idbase,domanialite,libellefrancaisarbreprecedent,
         especearbreprecedent,datedernierabattage,motifabattagearbreprecedent)  |>
  mutate(circonferenceencm=NA,hauteurenm=NA,dateplantation=NA) |>
  rename_with(\(colname){gsub("arbreprecedent","",colname)},ends_with("arbreprecedent"))

setdiff(colnames(planted_tree_cleaned),colnames(cutted_tree_cleaned))
setdiff(colnames(cutted_tree_cleaned),colnames(planted_tree_cleaned))

paris_trees = bind_rows(planted_tree_cleaned,cutted_tree_cleaned) |>
  mutate(status = if_else(!is.na(datedernierabattage),"cutted","planted"))


saveRDS(paris_trees,"./data/paris_trees.RDS")

big_database=st_read("./data/les-arbres(1).geojson")

saveRDS(big_database,"./data/paris_trees_big.RDS")


